__version__ = '1.1.2'
import warnings
warnings.filterwarnings('ignore')
from . SpaDecon import SpaDecon
